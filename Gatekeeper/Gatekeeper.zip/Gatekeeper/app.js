const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const gatekeeper = require('./gatekeeper');
const cors = require('cors'); 
app.use(cors());
app.use(bodyParser.json());

// Mount the gatekeeper as a middleware
app.use('/api', gatekeeper);

// Start the server
app.listen(3000, () => {
  console.log('Server is running on port 3000');
});
