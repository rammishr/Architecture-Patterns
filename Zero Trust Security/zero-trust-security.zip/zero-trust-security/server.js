const express = require('express');
const jwt = require('jsonwebtoken');
const cors = require('cors');

const app = express();
const secretKey = 'my-secret-key';
const secretKeyString = Buffer.from(secretKey);


app.use(cors());

const verifyToken = (req, res, next) => {
  const token = req.headers['authorization'];
 console.log("Received Token " + token);
  if (!token) {
    return res.status(403).json({ message: 'Token not provided' });
  }

  jwt.verify(token, secretKeyString, (err, decoded) => {
    if (err) {
      console.error('Failed to authenticate token:', err); // Add debug log
      return res.status(401).json({ message: 'Failed to authenticate token' });
    }

    req.user = decoded;
    next();
  });
};

app.get('/public', (req, res) => {
  res.json({ message: 'Public endpoint' });
});

app.get('/protected', verifyToken, (req, res) => {
  res.json({ message: 'Protected endpoint', user: req.user });
});

app.post('/login', (req, res) => {
  console.log("Received login request to generate token");
  const user = {
    id: 123,
    username: 'ram.krushna'
  };
 res.json({ token : jwt.sign(user, secretKeyString)});
  
});


const port = 3000;
app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
});
