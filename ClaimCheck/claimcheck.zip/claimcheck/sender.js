const fs = require('fs');
const path = require('path');
const uuid = require('uuid');

const storageFilePath = path.join(__dirname, 'redis.txt');

// Simulate the sender component storing the payload in a file
function storePayload(payload) {
  return new Promise((resolve, reject) => {
    const claimCheck = uuid.v4();
    
    fs.readFile(storageFilePath, 'utf8', (err, data) => {
      if (err && err.code !== 'ENOENT') {
        reject(err);
      } else {
        const payloads = data ? JSON.parse(data) : {};
        payloads[claimCheck] = payload;

        fs.writeFile(storageFilePath, JSON.stringify(payloads), 'utf8', (err) => {
          if (err) {
            reject(err);
          } else {
            resolve(claimCheck);
          }
        });
      }
    });
  });
}

// Generate a sample payload
const payload = {
  message: 'Hello, recipient!',
  data: { key: 'value' }
};

// Store the payload and obtain the claim check
storePayload(payload)
  .then(claimCheck => {
    console.log('Claim Check:', claimCheck);
  })
  .catch(error => {
    console.error('Error:', error.message);
  });
