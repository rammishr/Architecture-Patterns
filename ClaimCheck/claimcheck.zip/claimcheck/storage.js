const storage = {};

module.exports = storage;
