const fs = require('fs');
const path = require('path');

const storageFilePath = path.join(__dirname, 'redis.txt');

// Simulate the recipient component retrieving the payload from the file
function retrievePayload(claimCheck) {
  return new Promise((resolve, reject) => {
    fs.readFile(storageFilePath, 'utf8', (err, data) => {
      if (err) {
        reject(err);
      } else {
        const payloads = JSON.parse(data);
        const payload = payloads[claimCheck];
        if (payload) {
          resolve(payload);
        } else {
          reject(new Error('Invalid claim check'));
        }
      }
    });
  });
}

// Retrieve the payload using the claim check obtained from the sender
const claimCheck = 'edc1b974-cfc6-4433-adf2-db3c496fc2bf'; // Replace with the claim check received from the sender

retrievePayload(claimCheck)
  .then(payload => {
    console.log('Payload:', payload);
  })
  .catch(error => {
    console.error('Error:', error.message);
  });
