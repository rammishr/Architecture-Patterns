// main.js (Node.js application)

const { spawn } = require('child_process');
const express = require('express');

const app = express();
const port = 3000;

// Start the sidecar
const sidecarProcess = spawn('node', ['sidecar.js']);

// Listen for messages from the sidecar
sidecarProcess.stdout.on('data', (data) => {
  console.log(`Sidecar stdout: ${data}`);
});

sidecarProcess.stderr.on('data', (data) => {
  console.error(`Sidecar stderr: ${data}`);
});

sidecarProcess.on('close', (code) => {
  console.log(`Sidecar process exited with code ${code}`);
});

// API endpoint that triggers the sidecar
app.get('/api/sidecar', (req, res) => {
  // Send a message to the sidecar
  sidecarProcess.stdin.write(JSON.stringify({
    type: 'greet',
    data: {
      name: 'John',
      age: 30
    }
  }) + '\n');

  res.send('Message sent to sidecar');
});

// API endpoint that welcomes user
app.get('/', (req, res) => {
    // Welcome User
    
  
    res.send('Welcome to sidecar Demo. Go to /api/sidecar to trigger it');
  });

app.listen(port, () => {
  console.log(`Main.js app listening at http://localhost:${port}`);
});
