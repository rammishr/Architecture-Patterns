// sidecar.js (Node.js sidecar)

const { spawn } = require('child_process');

process.stdin.setEncoding('utf8');

process.stdin.on('data', (data) => {
  const message = JSON.parse(data);

  if (message.type === 'greet') {
    greet(message.data);
  }
});

function greet(data) {
  const pythonProcess = spawn('python', ['greet.py', data.name, data.age]);

  pythonProcess.stdout.on('data', (data) => {
    console.log(`Python stdout: ${data}`);
  });

  pythonProcess.stderr.on('data', (data) => {
    console.error(`Python stderr: ${data}`);
  });

  pythonProcess.on('close', (code) => {
    console.log(`Python process exited with code ${code}`);
  });
}
