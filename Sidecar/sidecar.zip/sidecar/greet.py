# greet.py (Python script)

import sys

name = sys.argv[1]
age = int(sys.argv[2])

print(f'Hello, {name}! You are {age} years old.')
