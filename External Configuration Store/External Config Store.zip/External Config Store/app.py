import etcd3

# Create an etcd client instance with the appropriate connection details
etcd_client = etcd3.client(host='localhost', port=2379)

# Set a key-value pair in etcd
def set_key_in_etcd(key, value):
    etcd_client.put(key, value)

# Read a key from etcd
def get_key_from_etcd(key):
    result = etcd_client.get(key)
    if result:
        return result[0]
    else:
        return None

# Set a key-value pair in etcd
set_key_in_etcd('/config/app/port', '5000')

# Read the key from etcd
config_value = get_key_from_etcd('/config/app/port')
if config_value:
    print(f'Configuration value retrieved from etcd: {config_value.decode("utf-8")}')
else:
    print('Configuration value not found in etcd')

