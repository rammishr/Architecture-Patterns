import etcd3

# Connect to the etcd server
etcd = etcd3.client(host='localhost', port=2379)

# Retrieve the etcd server version
server_version = etcd.status().version
print(f"Etcd server version: {server_version}")

