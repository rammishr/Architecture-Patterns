// orderService.js
const express = require('express');
const amqp = require('amqplib');
const app = express();
const port = 3000;

async function setup() {
  const connection = await amqp.connect('amqp://127.0.0.1:5672');
  const channel = await connection.createChannel();

  await channel.assertQueue('payment_queue');

  app.post('/orders', (req, res) => {
    // Process order creation logic
    // Generate order ID

    // Publish a message to the payment queue
    const message = { type: 'payment.create', data: { orderId: '123' } };
    channel.sendToQueue('payment_queue', Buffer.from(JSON.stringify(message)));

    res.send('Order created successfully');
  });

  app.listen(port, () => {
    console.log('Order Service is listening on port ' + port);
  });
}

setup();
