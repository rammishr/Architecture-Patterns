// paymentService.js
const amqp = require('amqplib');

async function setup() {
  const connection = await amqp.connect('amqp://127.0.0.1:5672');
  const channel = await connection.createChannel();

  await channel.assertQueue('payment_queue');

  channel.consume('payment_queue', (message) => {
    const event = JSON.parse(message.content.toString());

    if (event.type === 'payment.create') {
      console.log('Payment created for Order ID:', event.data.orderId);

      // Publish a message to the shipping queue
      const shippingEvent = { type: 'shipping.create', data: { orderId: event.data.orderId } };
      channel.sendToQueue('shipping_queue', Buffer.from(JSON.stringify(shippingEvent)));
    }

    channel.ack(message);
  });

  console.log('Payment Service is ready');
}

setup();
