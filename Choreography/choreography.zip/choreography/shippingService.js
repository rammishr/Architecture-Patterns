// shippingService.js
const amqp = require('amqplib');

async function setup() {
  const connection = await amqp.connect('amqp://127.0.0.1:5672');
  const channel = await connection.createChannel();

  await channel.assertQueue('shipping_queue');

  channel.consume('shipping_queue', (message) => {
    const event = JSON.parse(message.content.toString());

    if (event.type === 'shipping.create') {
      console.log('Shipping created for Order ID:', event.data.orderId);
    }

    channel.ack(message);
  });

  console.log('Shipping Service is ready');
}

setup();
