const express = require('express');
const app = express();

// Rate Limiting Variables
const componentALimit = 1 // Maximum 5 requests per interval
const componentALimitInterval = 1000; // 1 second interval
let componentATokenBucket = componentALimit;

const componentBLimit = 3; // Maximum 10 requests per interval
const componentBLimitInterval = 3000; // 1 second interval
let componentBTokenBucket = componentBLimit;

const componentCLimit = 4; // Maximum 3 requests per interval
const componentCLimitInterval = 5000; // 1 second interval
let componentCTokenBucket = componentCLimit;

// Component A
app.get('/componentA', (req, res) => {
  if (componentATokenBucket > 0) {
    console.log('Component A received a request');
    res.send('Component A response');
    componentATokenBucket--;
    setTimeout(() => {
      componentATokenBucket = Math.min(componentALimit, componentATokenBucket + 1);
    }, componentALimitInterval);
  } else {
    console.log('Component A rate limit exceeded');
    res.status(429).send('Too Many Requests');
  }
});

// Component B
app.get('/componentB', (req, res) => {
  if (componentBTokenBucket > 0) {
    console.log('Component B received a request');
    res.send('Component B response');
    componentBTokenBucket--;
    setTimeout(() => {
      componentBTokenBucket = Math.min(componentBLimit, componentBTokenBucket + 1);
    }, componentBLimitInterval);
  } else {
    console.log('Component B rate limit exceeded');
    res.status(429).send('Too Many Requests');
  }
});

// Component C
app.get('/componentC', (req, res) => {
  if (componentCTokenBucket > 0) {
    console.log('Component C received a request');
    res.send('Component C response');
    componentCTokenBucket--;
    setTimeout(() => {
      componentCTokenBucket = Math.min(componentCLimit, componentCTokenBucket + 1);
    }, componentCLimitInterval);
  } else {
    console.log('Component C rate limit exceeded');
    res.status(429).send('Too Many Requests');
  }
});

app.listen(3000, () => {
  console.log('Server is running on port 3000');
});

