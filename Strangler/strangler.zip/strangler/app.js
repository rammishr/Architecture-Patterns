const express = require('express');
const bodyParser = require('body-parser');
//const newCheckout = require('./newCheckout.js');

const app = express();
app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.json());
app.use(function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Methods", "GET, PUT, POST, DELETE, OPTIONS");
  res.header("Access-Control-Allow-Headers", "Content-Type, Authorization, Content-Length, X-Requested-With");
  next();
});

// Strangler middleware function
app.post('/checkout', async function(req, res, next) {
  // Check if request is for legacy checkout system
  if (req.body.gateway === 'legacy') {
    // Process payment using new checkout system
    const newCheckout = (await import('./newCheckout.js')).default;
    const transactionId = await newCheckout.processPayment(req.body.details);
    // Send response
    res.send({ success: true, transactionId });
  } else {
    // Send response
    const id = 'newTxnDirect : ';
    res.send({ success: true, id });
  }
});

// Legacy checkout endpoint
app.post('/legacy/checkout', async function(req, res) {
  try {
    // Send request to new checkout system
    const fetch = (await import('node-fetch')).default;
    const response = await fetch('http://localhost:3000/checkout', {
      method: 'POST',
      body: JSON.stringify({
        gateway: 'legacy',
        details: req.body,
      }),
      headers: { 'Content-Type': 'application/json' },
    });

    const data = await response.json();
    // Send response
    res.send(data);
  } catch (error) {
    // Handle errors
    res.status(500).send({ error: 'Internal Server Error' });
  }
});

app.listen(3000, function() {
  console.log('App listening on port 3000');
});
