// newCheckout.js

function processPayment(paymentDetails) {
  // Process payment using new payment gateway
  // ...

  // Return transaction ID
  return 'newTxnFromLegacy';
}

module.exports = {
  processPayment,
};

