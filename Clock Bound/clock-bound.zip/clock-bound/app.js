const ntpClient = require('ntp-client');

async function getNodeTimestamp() {
  return new Promise((resolve, reject) => {
    ntpClient.getNetworkTime("pool.ntp.org", 123, (err, date) => {
      if (err) {
        reject(err);
      } else {
        resolve(date);
      }
    });
  });
}

const node1 = async () => {
  const timestamp = await getNodeTimestamp();
  console.log("Node 1: timestamp =", timestamp);
};

const node2 = async () => {
  const timestamp = await getNodeTimestamp();
  console.log("Node 2: timestamp =", timestamp);
};

async function main() {
  await node1();
  await node2();
}

main();

