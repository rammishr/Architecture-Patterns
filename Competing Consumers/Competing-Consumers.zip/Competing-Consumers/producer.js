const amqp = require('amqplib');

async function publishMessage(message) {
  try {
    // Connect to RabbitMQ server
    const connection = await amqp.connect('amqp://127.0.0.1');
    const channel = await connection.createChannel();

    // Declare a message queue
    const queue = 'messageQueue';
    await channel.assertQueue(queue);

    // Publish a message to the queue
    const jsonMessage = JSON.stringify(message);
    channel.sendToQueue(queue, Buffer.from(jsonMessage));

    console.log(`Message published: ${jsonMessage}`);

    // Close the connection
    setTimeout(() => {
      connection.close();
    }, 500);
  } catch (error) {
    console.error('Error occurred:', error);
  }
}

// Generate and publish messages every 1 second
setInterval(() => {
  const randomValue = Math.floor(Math.random() * 10) + 1;
  const message = {
    value: randomValue,
    timestamp: new Date().toISOString(),
  };
  publishMessage(message);
}, 1000);
