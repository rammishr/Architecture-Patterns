const amqp = require('amqplib');

async function consumeMessages() {
  try {
    // Connect to RabbitMQ server
    const connection = await amqp.connect('amqp://127.0.0.1');
    const channel = await connection.createChannel();

    // Declare the message queue
    const queue = 'messageQueue';
    await channel.assertQueue(queue);

    // Configure the queue to dispatch messages in a round-robin manner
    await channel.prefetch(1);

    // Consume messages from the queue
    channel.consume(queue, (message) => {
      const messageContent = message.content.toString();
      console.log(`Consumer received message: ${messageContent}`);

      try {
        // Parse the message as JSON
        const data = JSON.parse(messageContent);

        // Perform some processing on the message
        const processedData = processData(data);

        console.log(`Consumer processed data: ${JSON.stringify(processedData)}`);

        // Simulate message processing
        setTimeout(() => {
          console.log(`Consumer finished processing: ${messageContent}`);

          // Acknowledge the message
          channel.ack(message);
        }, 2000);
      } catch (error) {
        console.error('Error occurred during message processing:', error);

        // Reject and requeue the message for error handling
        channel.reject(message, false);
      }
    }, { noAck: false });

    console.log('Consumer started. Waiting for messages...');
  } catch (error) {
    console.error('Error occurred:', error);
  }
}

// Process the message data (dummy implementation)
function processData(data) {
  // Add a timestamp to the data
  const processedData = {
    ...data,
    timestamp: new Date().toISOString(),
  };

  // Perform some additional processing tasks
  processedData.result = processedData.value * 2;

  return processedData;
}

// Start consuming messages
consumeMessages().catch(console.error);
