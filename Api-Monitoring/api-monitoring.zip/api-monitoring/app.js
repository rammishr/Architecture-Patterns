const express = require('express');
const { registerInstrumentations } = require('@opentelemetry/instrumentation');
const { NodeTracerProvider } = require('@opentelemetry/node');
const { JaegerExporter } = require('@opentelemetry/exporter-jaeger');
const { SimpleSpanProcessor } = require('@opentelemetry/tracing');

const { ExpressInstrumentation } = require('@opentelemetry/instrumentation-express');

const app = express();

// Initialize the OpenTelemetry tracer provider
const provider = new NodeTracerProvider();

// Create a Jaeger exporter to send trace data
const exporter = new JaegerExporter({
  serviceName: 'your-service-name', // Replace with your service name
  host: 'localhost', // Replace with your Jaeger agent host
  port: 6831, // Replace with your Jaeger agent port
});

// Register the exporter with the tracer provider
provider.addSpanProcessor(new SimpleSpanProcessor(exporter));
provider.register();

// Enable instrumentation
const instrumentations = {
  instrumentations: [ExpressInstrumentation],
  tracerProvider: provider,
};
registerInstrumentations(instrumentations);

app.get('/', (req, res) => {
  res.send('Hello World!');
});

app.listen(3000, () => {
  console.log('Server started on port 3000');
});
