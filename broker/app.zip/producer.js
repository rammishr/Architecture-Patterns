const { Kafka } = require('kafkajs');
const readline = require('readline');

// Create a new KafkaJS client instance
const kafka = new Kafka({
  clientId: 'my-app',
  brokers: ['localhost:9092']
});

// Create a new KafkaJS producer
const producer = kafka.producer();

// Create a readline interface to read user input from the console
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

// Define a function to send a message to the Kafka topic
async function sendMessage(message) {
  await producer.send({
    topic: 'my-topic',
    messages: [{ value: message }]
  });
  console.log(`Sent message: ${message}`);
}

// Prompt the user for input and send it as a message to the Kafka topic
rl.question('Enter a message to send to the Kafka topic: ', async (message) => {
  await sendMessage(message);
  rl.close();
  process.exit(0);
});

// Connect the producer to the Kafka cluster
producer.connect();
