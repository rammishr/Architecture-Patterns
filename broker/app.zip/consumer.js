const { Kafka } = require('kafkajs');

// Create a new KafkaJS client instance
const kafka = new Kafka({
  clientId: 'my-app',
  brokers: ['localhost:9092']
});

// Create a new KafkaJS consumer
const consumer = kafka.consumer({ groupId: 'my-group' });

// Define a function to consume messages from the Kafka topic
async function consumeMessages() {
  await consumer.connect();
  await consumer.subscribe({ topic: 'my-topic', fromBeginning: true });

  await consumer.run({
    eachMessage: async ({ topic, partition, message }) => {
      console.log(`Received message: ${message.value.toString()}`);
    }
  });
}

// Call the consumeMessages function to start consuming messages
consumeMessages();
