const express = require('express');
const http = require('http');
const WebSocket = require('ws');

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });


const blackboard = {
  comments: [],
  positiveCount: 0,
  negativeCount: 0,
  completed: false
};

function tokenizer() {
  const comments = blackboard.comments;
  const words = [];
  console.log(comments);
  for (let i = 0; i < comments.length; i++) {
    const comment = comments[i];
    const tokens = comment.split(' ');

    for (let j = 0; j < tokens.length; j++) {
      const token = tokens[j];
      words.push(token);
    }
  }

  blackboard.words = words;
  blackboard.completed = true;
}

function analyzer() {
  const words = blackboard.words;

  for (let i = 0; i < words.length; i++) {
    const word = words[i];
     console.log(" Word is " + word);
    if (positiveWords.includes(word)) {
      blackboard.positiveCount++;
    } else if (negativeWords.includes(word)) {
      blackboard.negativeCount++;
    }
  }

  blackboard.completed = true;
}

wss.on('connection', (ws) => {
  console.log('A user connected');

  ws.on('message', (comment) => {
    console.log(comment.toString());
    blackboard.comments = []; 
    blackboard.comments.push(comment.toString());
    blackboard.positiveCount = 0;
    blackboard.negativeCount = 0;
    blackboard.completed = false;

    tokenizer();
    analyzer();

    wss.clients.forEach((client) => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(JSON.stringify({
          positiveCount: blackboard.positiveCount,
          negativeCount: blackboard.negativeCount,
          completed: blackboard.completed
        }));
      }
    });
  });
});

const positiveWords = ['love', 'great', 'fantastic'];
const negativeWords = ['terrible', 'awful', 'bad'];

const port = process.env.PORT || 3000;
server.listen(port, () => {
  console.log(`Server listening on port ${port}`);
});
