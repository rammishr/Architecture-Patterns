const { Dispatcher } = require('flux');

const dispatcher = new Dispatcher();

module.exports = dispatcher;
