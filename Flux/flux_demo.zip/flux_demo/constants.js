module.exports = {
  HELLO_WORLD: 'HELLO_WORLD'
};
