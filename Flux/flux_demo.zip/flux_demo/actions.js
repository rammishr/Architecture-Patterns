const dispatcher = require('./dispatcher');
const constants = require('./constants');

const actions = {
  sayHello: function() {
    dispatcher.dispatch({
      type: constants.HELLO_WORLD,
      payload: {}
    });
  }
};

module.exports = actions;
