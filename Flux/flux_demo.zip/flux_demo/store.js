const { EventEmitter } = require('events');
const dispatcher = require('./dispatcher');
const constants = require('./constants');

const store = Object.assign({}, EventEmitter.prototype, {
  addListener: function(callback) {
    this.on(constants.HELLO_WORLD, callback);
  },

  removeListener: function(callback) {
    this.removeListener(constants.HELLO_WORLD, callback);
  }
});

dispatcher.register(function(action) {
  switch(action.type) {
    case constants.HELLO_WORLD:
      store.emit(constants.HELLO_WORLD);
      break;
    default:
      // do nothing
  }
});

module.exports = store;
