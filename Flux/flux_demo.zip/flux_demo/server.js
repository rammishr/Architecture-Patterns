const React = require('react');
const ReactDOM = require('react-dom');
const actions = require('./actions');
const store = require('./store');

class HelloWorld extends React.Component {
  constructor(props) {
    super(props);
    this.state = { message: 'Hello, world!' };
    this.handleStoreChange = this.handleStoreChange.bind(this);
  }

  componentDidMount() {
    store.addListener(this.handleStoreChange);
  }

  componentWillUnmount() {
    store.removeListener(this.handleStoreChange);
  }

  handleStoreChange() {
    this.setState({ message: 'Hello, Flux!' });
  }

  handleClick() {
    actions.sayHello();
  }

  render() {
    return (
      <div>
        <h1>{this.state.message}</h1>
        <button onClick={this.handleClick}>Say Hello</button>
      </div>
    );
  }
}

ReactDOM.render(<HelloWorld />, document.getElementById('root'));
