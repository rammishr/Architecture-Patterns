const express = require('express');
const multer = require('multer');
const through2 = require('through2');
const { Readable } = require('stream');
const fs = require('fs');

const app = express();
const upload = multer();

// Define the filters
const inputFilter = through2.obj(function (chunk, encoding, callback) {
  const fileContents = chunk.toString().toUpperCase();
  callback(null, fileContents);
});

const lineCountFilter = through2.obj(function (chunk, encoding, callback) {
  const lineCount = chunk.toString().split('\n').length;
  callback(null, `Line count: ${lineCount}`);
});

const outputFilter = through2.obj(function (chunk, encoding, callback) {
  const output = { count: chunk.toString() };
  fs.writeFileSync('output.json', JSON.stringify(output));
  callback();
});

// Define the routes
app.get('/', (req, res) => {
  res.render('index.ejs');
});

app.post('/', upload.single('myfile'), (req, res) => {
  const fileStream = Readable.from(req.file.buffer);

  fileStream
    .pipe(inputFilter)
    .pipe(lineCountFilter)
    .pipe(outputFilter)
    .on('finish', () => {
      const output = fs.readFileSync('output.json', 'utf8');
      res.render('output.ejs', { output });
    });
});

// Start the server
app.listen(3000, () => {
  console.log('Server listening on port 3000');
});
