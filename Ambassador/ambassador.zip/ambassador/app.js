process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';

const express = require('express');
const cors = require('cors');
const axios = require('axios');

const app = express();
const PORT = 3000;
const EXTERNAL_SERVICE_URL = 'https://jsonplaceholder.typicode.com/posts'; // Replace with the actual external service URL
const PAYMENT_GATEWAY_URL = 'https://reqres.in/api/users'; // Replace with the actual payment gateway URL

app.use(cors()); // Enable CORS for all routes

// Route handler for incoming payment requests
app.post('/api/pay', async (req, res) => {
  try {
    // Perform the necessary authentication process for the payment gateway
    await authenticate();

    // Make a request to the external service using the Ambassador
    const externalServiceResponse = await axios.get(EXTERNAL_SERVICE_URL);

    // Make a request to the payment gateway using the Ambassador
    const paymentGatewayResponse = await axios.post(PAYMENT_GATEWAY_URL, req.body);

    // Combine the responses and return to the client
    const combinedResponse = {
      externalServiceResponse: externalServiceResponse.data,
      paymentGatewayResponse: paymentGatewayResponse.data
    };
    
    res.json(combinedResponse);
  } catch (error) {
    console.error('Payment Failed:', error);
    // Handle any errors that occur during the payment process
    res.status(500).json({ error: 'Payment failed' });
  }
});

// Authentication process with the payment gateway
async function authenticate() {
  // Perform the authentication logic here (e.g., generate access tokens, validate credentials)
  // ...
  // Simulating authentication delay
  await new Promise((resolve) => setTimeout(resolve, 1000));
}

// Start the server
app.listen(PORT, () => {
  console.log(`Ambassador microservice listening on port ${PORT}`);
});
