const axios = require('axios');

process.env['NODE_TLS_REJECT_UNAUTHORIZED'] = '0';


// Internal System Domain Model
class Customer {
  constructor(id, name, email) {
    this.id = id;
    this.name = name;
    this.email = email;
  }
}

// Anti-corruption Layer
class CRMAdapter {
  async getCustomers() {
    const externalCustomers = await this.fetchCRMCustomers();
    const internalCustomers = externalCustomers.map(this.transformCustomer);
    return internalCustomers;
  }

  async fetchCRMCustomers() {
    try {
      const response = await axios.get('https://jsonplaceholder.typicode.com/users', { rejectUnauthorized: false });
      return response.data;
    } catch (error) {
      console.error('Error fetching CRM customers:', error);
      return [];
    }
  }

  transformCustomer(externalCustomer) {
    const id = externalCustomer.id;
    const name = externalCustomer.name;
    const email = externalCustomer.email;
    return new Customer(id, name, email);
  }
}

// Usage
async function main() {
  const crmAdapter = new CRMAdapter();

  const internalCustomers = await crmAdapter.getCustomers();
  console.log(internalCustomers);
}

main();
