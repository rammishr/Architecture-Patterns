const Seneca = require('seneca');
const seneca = Seneca();

seneca.add({ role: 'order', cmd: 'addItem' }, function (msg, done) {
  console.log('Order details:', msg);
  seneca.act({ role: 'catalog', cmd: 'getProduct', id: msg.item.id || msg.id }, function (err, product) {

    //if (err) return done(err);
    console.log('order details 1:', msg.item);
    

    done(null, msg.item);
  });
});

seneca.add({ role: 'order', cmd: 'checkout' }, function (msg, done) {
  console.log('checkout ',msg)
  seneca.act({ role: 'payment', cmd: 'process', amount: msg.amount }, function (err, result) {

    const order = {
      id: Date.now(),
      items: msg.items,
      total: msg.amount,
      status: 'completed'
    };

    done(null, order);
  });
});

seneca.listen({ type: 'tcp', port: 3002 });
console.log('Order service started');
