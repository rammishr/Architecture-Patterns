const Seneca = require('seneca');
const seneca = Seneca();

seneca.add({ role: 'catalog', cmd: 'getProduct', id: '*' }, function (msg, done) {
  console.log('catalog details:', msg);
  const product = {
    id: msg.id,
    name: 'Product ' + msg.id,
    price: Math.floor(Math.random() * 100)
  };
 console.log('product details:', product);
  done(null, product);
});

seneca.listen({ type: 'tcp', port: 3001 });
console.log('Catalog service started');
