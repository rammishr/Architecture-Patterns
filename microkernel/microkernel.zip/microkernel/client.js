const Seneca = require('seneca');
const seneca = Seneca();

seneca.client({ type: 'tcp', port: 3000 });
seneca.client({ type: 'tcp', port: 3001, pin: { role: 'catalog', cmd: '*' } });
seneca.client({ type: 'tcp', port: 3002, pin: { role: 'order', cmd: '*' } });
seneca.client({ type: 'tcp', port: 3003, pin: { role: 'payment', cmd: '*' } });

seneca.ready(function () {
  const productId = 1;
  const quantity = 2;

  seneca.act({ role: 'catalog', cmd: 'getProduct', id: productId }, function (err, product) {
    if (err) return console.error(err);

    console.log('Product details:', product);

    const item = {
      id: product.id,
      name: product.name,
      price: product.price,
      quantity: quantity
    };

    seneca.act({ role: 'order', cmd: 'addItem', item: item }, function (err, item) {
      if (err) return console.error(err);

      console.log('Item added:', item);

      const items = [item];
      const amount = item.price * quantity;

      seneca.act({ role: 'order', cmd: 'checkout', items: items, amount: amount }, function (err, order) {
        if (err) return console.error(err);

        console.log('Order placed:', order);
      });
    });
  });
});
