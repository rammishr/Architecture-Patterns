const Seneca = require('seneca');
const seneca = Seneca();

seneca.add({ role: 'payment', cmd: 'process' }, function (msg, done) {
  // simulate processing payment by waiting for 1 second
  console.log('payment details:', msg);
  setTimeout(function () {
    done
(null, { status: 'success', message: 'Payment processed successfully' });
}, 1000);
});

seneca.listen({ type: 'tcp', port: 3003 });
console.log('Payment service started');