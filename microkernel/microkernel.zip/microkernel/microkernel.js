const Seneca = require('seneca');
const seneca = Seneca();

seneca.listen({ type: 'tcp', port: 3000 });
console.log('Microkernel started');
