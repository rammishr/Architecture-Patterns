const express = require('express');
const app = express();
const cors = require('cors');

app.use(cors());

// Simulated resource data
const resources = [
  { id: 1, name: 'Resource 1', accessKey: 'abc123' },
  { id: 2, name: 'Resource 2', accessKey: 'def456' },
  { id: 3, name: 'Resource 3', accessKey: 'ghi789' },
];

// Middleware to authenticate and authorize valet key
function authenticateValetKey(req, res, next) {
  const valetKey = req.headers['valet-key'];
  const resourceId = parseInt(req.params.id);

  // Check if valet key is provided
  if (!valetKey) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  // Check if valet key is valid for the requested resource
  const resource = resources.find((r) => r.id === resourceId);
  if (!resource || resource.accessKey !== valetKey) {
    return res.status(403).json({ error: 'Forbidden' });
  }

  // Pass the resource object to the next middleware
  req.resource = resource;
  next();
}


// Default handler to display available resource paths
app.get('/', (req, res) => {
  const paths = resources.map((r) => `/resources/${r.id}`);
  res.send(`Available resource paths: ${paths.join(', ')}`);
});

app.get('/resources', (req, res) => {
  res.json({ resources });
});

// Protected route accessible only with valet key
app.get('/resources/:id', authenticateValetKey, (req, res) => {
  const resourceId = parseInt(req.params.id);
  const resource = resources.find((r) => r.id === resourceId);

  if (!resource) {
    return res.status(404).json({ error: 'Resource not found' });
  }

  res.json({ resource });
});

// Serve test.html file for validation
app.use(express.static(__dirname));

// Start the server
app.listen(3000, () => {
  console.log('Server started on port 3000');
});
