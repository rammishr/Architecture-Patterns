const express = require('express');
const redis = require('redis');
const bodyParser = require('body-parser');
const app = express();

const client = redis.createClient();

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

app.post('/data', function(req, res) {
  const id = req.body.id;
  const data = req.body.data;
  client.set(id, JSON.stringify(data), function(err, reply) {
    if (err) {
      console.error(err);
      res.status(500).send('Error adding data!');
    } else {
      res.send('Data added successfully!');
    }
  });
});

app.get('/data', function(req, res) {
  const id = req.query.id;
  client.get(id, function(err, reply) {
    if (err) {
      console.error(err);
      res.status(500).send('Error retrieving data!');
    } else if (reply) {
      res.send(JSON.parse(reply));
    } else {
      res.status(404).send('Data not found!');
    }
  });
});

app.listen(3000, function() {
  console.log('Server running at http://localhost:3000');
});
